<div class="list-group">
	<a class="list-group-item" href="index.php?toc=developer&p=admin/overview">Developer</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_oauth">oAuth</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_methods">Request Formats</a>
</div>

<h4>Methods</h4>
<div class="list-group">
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_displays">Displays</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_displaygroups">Display Groups</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_layouts">Layouts</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_library">Library</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_schedule">Schedule</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_template">Template</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_resolution">Resolution</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_modules">Modules</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_misc">Miscellaneous</a>
</div>
