<div class="list-group">
	<a class="list-group-item" href="index.php?toc=user_and_display&p=users/overview">Overview</a>
	<a class="list-group-item" href="index.php?toc=user_and_display&p=users/users">User Administration</a>
	<a class="list-group-item" href="index.php?toc=user_and_display&p=users/menu_page_security">Page &amp; Menu Security</a>
	<a class="list-group-item" href="index.php?toc=user_and_display&p=users/user_types">User Types</a>
	<a class="list-group-item" href="index.php?toc=user_and_display&p=users/groups">User Groups</a>
	<a class="list-group-item" href="index.php?toc=user_and_display&p=users/user_permissions">Permissions Model</a>
	<a class="list-group-item" href="index.php?toc=user_and_display&p=admin/displays">Display Administration</a>
	<a class="list-group-item" href="index.php?toc=user_and_display&p=admin/displaygroups">Display Groups</a>
	<a class="list-group-item" href="index.php?toc=user_and_display&p=admin/displaystats">Display Statistics</a>
	<a class="list-group-item" href="index.php?toc=user_and_display&p=admin/display_wakeonlan">Display Wake on LAN</a>
	<a class="list-group-item" href="index.php?toc=user_and_display&p=admin/fileassociations">File Associations</a>
</div>