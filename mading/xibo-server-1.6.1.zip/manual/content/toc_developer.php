<div class="list-group">
	<a class="list-group-item" href="index.php?toc=developer&p=admin/overview">Overview</a>
	<a class="list-group-item" href="index.php?toc=developer&p=admin/advanced">Troubleshooting</a>
	<a class="list-group-item" href="index.php?toc=developer&p=admin/theme">Theme</a>
	<a class="list-group-item" href="index.php?toc=developer_api&p=admin/api_overview">API</a>
	<a class="list-group-item" href="index.php?toc=developer_releasenotes&p=admin/release_notes">Release Notes</a>
	<a class="list-group-item" href="index.php?toc=developer&p=admin/contributing">Contributing</a>
	<a class="list-group-item" href="index.php?toc=developer&p=admin/blueprints"><?php echo PRODUCT_NAME; ?> Blueprints</a>
	<a class="list-group-item" href="index.php?toc=developer&p=admin/database_model"><?php echo PRODUCT_NAME; ?> CMS Database Model</a>
	<a class="list-group-item" href="index.php?toc=developer&p=admin/pyclient_libbrowsernode_build">Ubuntu Client Binary Dependancy Build Instructions</a>
</div>
