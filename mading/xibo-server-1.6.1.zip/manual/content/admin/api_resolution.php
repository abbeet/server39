
<h3> <span class="mw-headline" id="Resolution"> Resolution </span></h3>
<ul><li> ResolutionList
</li></ul>